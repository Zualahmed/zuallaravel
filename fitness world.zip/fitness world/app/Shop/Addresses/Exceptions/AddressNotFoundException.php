<?php

namespace App\Shop\Addresses\Exceptions;

class AddressNotFoundException extends \Exception
{
}
