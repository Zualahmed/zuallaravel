<?php

namespace App\Shop\Carts\Exceptions;

class ProductInCartNotFoundException extends \Exception
{
}
