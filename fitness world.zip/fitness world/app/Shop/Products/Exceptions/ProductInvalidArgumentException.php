<?php

namespace App\Shop\Products\Exceptions;

class ProductInvalidArgumentException extends \Exception
{
}
