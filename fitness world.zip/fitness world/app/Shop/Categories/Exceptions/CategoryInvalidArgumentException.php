<?php

namespace App\Shop\Categories\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class CategoryInvalidArgumentException extends InvalidArgumentException
{
}
