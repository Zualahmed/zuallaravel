<?php

namespace App\Shop\Permissions\Exceptions;

class UpdatePermissionErrorException extends \Exception
{
}
