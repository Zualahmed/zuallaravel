<?php

namespace App\Shop\Permissions\Exceptions;

class DeletePermissionErrorException extends \Exception
{
}
