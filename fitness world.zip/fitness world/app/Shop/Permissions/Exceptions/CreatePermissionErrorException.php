<?php

namespace App\Shop\Permissions\Exceptions;

class CreatePermissionErrorException extends \Exception
{
}
